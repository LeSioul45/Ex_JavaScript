// Fichier ex01/test1.js
console.log('test1 dit: Bonjour!');
