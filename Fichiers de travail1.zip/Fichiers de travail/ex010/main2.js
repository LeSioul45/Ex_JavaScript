// Fichier ex010/main2.js
console.log('main2 dit: Bonjour!');
require('./lib/test2.js');
require('./lib/test2.js');
