// Fichier ex010/main4.js
console.log('main4 dit: Bonjour!');
msg = 'Bonjour!'; // ou GLOBAL.msg
require('./lib/test3.js');
