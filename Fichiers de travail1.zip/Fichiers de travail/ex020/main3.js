// Fichier ex020/main3.js
var user = require('./lib/user3.js');
console.log('User version: ' + user.version);
user.say("Alice", "Bonjour");
user.say("Maïa", "Bonjour");
