// Fichier ex02/main2.js
var user = require('./lib/user2.js');
user.say("Alice", "Bonjour");
user.say("Maïa", "Bonjour");
