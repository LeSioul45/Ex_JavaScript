// Fichier ex020/main1.js
function say(user, msg) {
  console.log(user + ' say: ' + msg);
}
say("Jacques", "Bonjour");
