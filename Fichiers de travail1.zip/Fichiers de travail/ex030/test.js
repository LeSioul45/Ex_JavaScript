element.addEventListener('click', function(event) {
    console.log('callback');
});
console.log('Ready');
