console.log('1');
element.addEventListener('click', function(event) {
      console.log('3');
});
console.log('2');
